<template>
  <button v-show="backToTopVisible" @click="scrollToTop" class="back-to-top">
    <svg
      t="1700211154804"
      class="icon"
      viewBox="0 0 1024 1024"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
      p-id="5914"
    >
      <path
        d="M882.12992 795.01824a25.6 25.6 0 0 0 8.6528-35.15392L560.16896 213.34528a56.32 56.32 0 0 0-19.03616-19.03616c-26.61376-16.09728-61.2352-7.5776-77.3376 19.03616L133.18144 759.86432a25.6 25.6 0 0 0 21.90336 38.85056h713.79456a25.6 25.6 0 0 0 13.25056-3.69664zM155.0848 849.91488c-42.41408 0-76.8-34.38592-76.8-76.8a76.8 76.8 0 0 1 11.08992-39.75168L419.98848 186.84416c30.73536-50.80576 96.83968-67.07712 147.64544-36.34176a107.52 107.52 0 0 1 36.34688 36.34176l330.61376 546.51904c21.95456 36.29056 10.32704 83.5072-25.9584 105.46176a76.8 76.8 0 0 1-39.7568 11.08992H155.0848z"
        p-id="5915"
      ></path>
    </svg>
  </button>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import '../../assets/global.scss'
const backToTopVisible = ref(false)
const updateVisibility = () => {
  backToTopVisible.value = document.body.scrollTop > 20 || document.documentElement.scrollTop > 20
}
const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  })
}
onMounted(() => {
  window.addEventListener('scroll', updateVisibility)
})
onUnmounted(() => {
  window.removeEventListener('scroll', updateVisibility)
})
</script>

<style lang="scss" scoped>
.back-to-top {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  width: 2.5rem;
  height: 2.5rem;
  background-color: var(--secondary-color);
  border: 1px solid var(--secondary-color);
  border-radius: 25%;
  padding: 0.5rem;
  cursor: pointer;
  z-index: 100;

  svg {
    fill: var(--light-text-color);
  }

  &:hover {
    background-color: #f3f3f3;
    svg {
      fill: var(--secondary-color);
    }
  }
}

@media (max-width: 768px) {
  .back-to-top {
    display: none;
  }
}
</style>
