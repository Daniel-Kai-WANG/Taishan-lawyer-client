<template>
  <hero-section />
  <major-section />
  <news-section />
  <team-section />
  <contact-section />
</template>

<script setup lang="ts">
import HeroSection from './components/HeroSection.vue'
import MajorSection from './components/MajorSection.vue'
import NewsSection from './components/NewsSection.vue'
import TeamSection from './components/TeamSection.vue'
import ContactSection from './components/ContactSection.vue'
</script>

<style lang="scss"></style>
